import Header from './components/layout/Header'
import Hero from './components/sections/Hero'
import About from './components/sections/About'
import Services from './components/sections/Services'
import Properties from './components/sections/Properties'
import Blog from './components/sections/Blog'
import CTA from './components/sections/CTA'
import Footer from './components/layout/Footer'

function App() {
  return (
    <>
      <Header />
      <main>
        <article>
          <Hero />
          <About />
          <Services />
          <Properties />
          <Blog />
          <CTA />
        </article>
      </main>
      <Footer />
    </>
  )
}

export default App
