import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

// Add Google Fonts
const link = document.createElement('link');
link.rel = 'stylesheet';
link.href = 'https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&family=Poppins:wght@400;500;600;700&display=swap';
document.head.appendChild(link);

// Add Ionicons
const ioniconsScript = document.createElement('script');
ioniconsScript.type = 'module';
ioniconsScript.src = 'https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js';
document.head.appendChild(ioniconsScript);

const ioniconsNoModuleScript = document.createElement('script');
ioniconsNoModuleScript.nomodule = true;
ioniconsNoModuleScript.src = 'https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js';
document.head.appendChild(ioniconsNoModuleScript);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
