import { useState } from 'react';
import '../../styles/EnquiryModal.css';

const LOCATIONS = [
  'New York',
  'Los Angeles',
  'Chicago',
  'Miami',
  'San Francisco',
  'Other'
];

const PREFERENCES = ['Flat', 'Plot', 'House'];

const BUDGET_MIN = 3000000; // 30 lakh
const BUDGET_MAX = 50000000; // 5 crore
const BUDGET_STEP = 100000; // 1 lakh

function formatBudget(value) {
  if (value >= 10000000) {
    // Show in crore
    return `${(value / 10000000).toFixed(2).replace(/\.00$/, '')} crore`;
  } else {
    // Show in lakh
    return `${(value / 100000).toFixed(2).replace(/\.00$/, '')} lakh`;
  }
}

const EnquiryModal = ({ open, onClose }) => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    location: '',
    budget: BUDGET_MIN,
    preference: ''
  });

  if (!open) return null;

  const handleChange = (e) => {
    const { name, value, type } = e.target;
    setForm((prev) => ({ ...prev, [name]: type === 'range' ? Number(value) : value }));
  };

  const handlePreference = (pref) => {
    setForm((prev) => ({ ...prev, preference: pref }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Enquiry submitted!');
    onClose();
  };

  return (
    <div className="enquiry-modal-overlay" onClick={onClose}>
      <div className="enquiry-modal" onClick={e => e.stopPropagation()}>
        <button className="enquiry-modal-close" onClick={onClose}>&times;</button>
        <h2>Enquiry Form</h2>
        <form onSubmit={handleSubmit} className="enquiry-form">
          <label>
            Name
            <input type="text" name="name" value={form.name} onChange={handleChange} required />
          </label>
          <label>
            Email
            <input type="email" name="email" value={form.email} onChange={handleChange} required />
          </label>
          <label>
            Phone Number
            <input type="tel" name="phone" value={form.phone} onChange={handleChange} required />
          </label>
          <label>
            Preferred Location
            <select name="location" value={form.location} onChange={handleChange} required>
              <option value="">Select a location</option>
              {LOCATIONS.map(loc => (
                <option key={loc} value={loc}>{loc}</option>
              ))}
            </select>
          </label>
          <label>
            Budget
            <div className="enquiry-budget-slider">
              <input
                type="range"
                name="budget"
                min={BUDGET_MIN}
                max={BUDGET_MAX}
                step={BUDGET_STEP}
                value={form.budget}
                onChange={handleChange}
              />
              <span className="enquiry-budget-value">{formatBudget(form.budget)}</span>
            </div>
          </label>
          <div className="enquiry-preference-group">
            <span>Preference</span>
            <div className="enquiry-preference-btns">
              {PREFERENCES.map((pref) => (
                <button
                  type="button"
                  key={pref}
                  className={`enquiry-pref-btn${form.preference === pref ? ' selected' : ''}`}
                  onClick={() => handlePreference(pref)}
                >
                  {pref}
                </button>
              ))}
            </div>
          </div>
          <button type="submit" className="btn" disabled={!form.preference}>Submit</button>
        </form>
      </div>
    </div>
  );
};

export default EnquiryModal; 