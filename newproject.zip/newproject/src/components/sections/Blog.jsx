import './../../styles/Blog.css';

const Blog = () => {
  return (
    <section className="blog" id="blog">
      <div className="container">
        <p className="section-subtitle">Blog</p>
        <h2 className="h2 section-title">Latest News & Articles</h2>
        <ul className="blog-list">
          <li className="blog-item">
            <img src="/assets/images/blog-1.png" alt="Blog 1" className="blog-img" />
            <div className="blog-content">
              <div className="blog-meta">
                <img src="/assets/images/author.jpg" alt="Author" className="blog-author" />
                <span>Admin</span>
                <span>Jan 10, 2024</span>
              </div>
              <h3 className="h3 blog-title">How to find the perfect home for your family</h3>
              <p className="blog-text">Tips and tricks to help you find the best home for your needs and budget.</p>
            </div>
          </li>
          <li className="blog-item">
            <img src="/assets/images/blog-2.jpg" alt="Blog 2" className="blog-img" />
            <div className="blog-content">
              <div className="blog-meta">
                <img src="/assets/images/author.jpg" alt="Author" className="blog-author" />
                <span>Admin</span>
                <span>Feb 2, 2024</span>
              </div>
              <h3 className="h3 blog-title">The benefits of living in a smart home</h3>
              <p className="blog-text">Discover how smart home technology can improve your lifestyle and security.</p>
            </div>
          </li>
          <li className="blog-item">
            <img src="/assets/images/blog-3.jpg" alt="Blog 3" className="blog-img" />
            <div className="blog-content">
              <div className="blog-meta">
                <img src="/assets/images/author.jpg" alt="Author" className="blog-author" />
                <span>Admin</span>
                <span>Mar 15, 2024</span>
              </div>
              <h3 className="h3 blog-title">Interior design trends for 2024</h3>
              <p className="blog-text">Stay up to date with the latest trends in home interior design and decor.</p>
            </div>
          </li>
        </ul>
      </div>
    </section>
  );
};

export default Blog; 