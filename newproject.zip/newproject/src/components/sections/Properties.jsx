import { useEffect, useRef, useState } from 'react';
import './../../styles/Properties.css';

const PROPERTIES = [
  {
    img: '/assets/images/property-1.jpg',
    title: 'Luxury Family Home',
    location: 'New York, USA',
    price: '$1,200,000',
  },
  {
    img: '/assets/images/property-2.jpg',
    title: 'Modern Apartment',
    location: 'Los Angeles, USA',
    price: '$850,000',
  },
  {
    img: '/assets/images/property-3.jpg',
    title: 'Cozy Condo',
    location: 'Chicago, USA',
    price: '$650,000',
  },
  {
    img: '/assets/images/property-4.png',
    title: 'Spacious Villa',
    location: 'Miami, USA',
    price: '$2,000,000',
  },
  // Add more properties as needed for testing
  {
    img: '/assets/images/property-1.jpg',
    title: 'Urban Loft',
    location: 'San Francisco, USA',
    price: '$1,500,000',
  },
  {
    img: '/assets/images/property-2.jpg',
    title: 'Beach House',
    location: 'Malibu, USA',
    price: '$3,200,000',
  },
  {
    img: '/assets/images/property-3.jpg',
    title: 'Country Estate',
    location: 'Austin, USA',
    price: '$2,800,000',
  },
  {
    img: '/assets/images/property-4.png',
    title: 'Downtown Studio',
    location: 'Boston, USA',
    price: '$900,000',
  },
];

function getSlidesPerView() {
  if (window.innerWidth >= 1200) return 4;
  if (window.innerWidth >= 992) return 3;
  if (window.innerWidth >= 600) return 2;
  return 1;
}

const Properties = () => {
  const [startIdx, setStartIdx] = useState(0);
  const [slidesPerView, setSlidesPerView] = useState(getSlidesPerView());
  const total = PROPERTIES.length;

  useEffect(() => {
    const handleResize = () => setSlidesPerView(getSlidesPerView());
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    setStartIdx(0); // Reset to first slide on slidesPerView change
  }, [slidesPerView]);

  const prev = () => {
    setStartIdx((prevIdx) => (prevIdx - 1 + total) % total);
  };
  const next = () => {
    setStartIdx((prevIdx) => (prevIdx + 1) % total);
  };

  // Get the properties for the current slide
  let visible = [];
  for (let i = 0; i < slidesPerView; i++) {
    visible.push(PROPERTIES[(startIdx + i) % total]);
  }

  // Dots: one for each possible starting index
  const totalDots = total;

  const goTo = (idx) => setStartIdx(idx);

  return (
    <section className="property" id="property">
      <div className="container">
        <p className="section-subtitle">Properties</p>
        <h2 className="h2 section-title">Featured Listings</h2>
        <div className="property-carousel">
          {/* Removed carousel arrows */}
          <ul className="property-list">
            {visible.map((prop, i) => (
              <li className="property-item" key={i + startIdx}>
                <img src={prop.img} alt={prop.title} className="property-img" />
                <div className="property-content">
                  <h3 className="h3 property-title">{prop.title}</h3>
                  <p className="property-location">{prop.location}</p>
                  <p className="property-price">{prop.price}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
        <div className="carousel-dots">
          {Array.from({ length: totalDots }).map((_, idx) => (
            <button
              key={idx}
              className={`carousel-dot${startIdx === idx ? ' active' : ''}`}
              onClick={() => goTo(idx)}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Properties; 