import './../../styles/Services.css';

const Services = () => {
  return (
    <section className="service" id="service">
      <div className="container">
        <p className="section-subtitle">Our Services</p>
        <h2 className="h2 section-title">Our Main Focus</h2>
        <ul className="service-list">
          <li className="service-item">
            <div className="service-icon">
              <img src="/assets/images/service-1.png" alt="Buy home" />
            </div>
            <h3 className="h3 service-title">Buy a home</h3>
            <p className="service-text">Over 1000 homes for sale available on the website, we can match you with a house you will want to call home.</p>
            <a href="#" className="btn">Find A Home</a>
          </li>
          <li className="service-item">
            <div className="service-icon">
              <img src="/assets/images/service-2.png" alt="Rent home" />
            </div>
            <h3 className="h3 service-title">Rent a home</h3>
            <p className="service-text">Over 1000 homes for rent available on the website, we can match you with a house you will want to call home.</p>
            <a href="#" className="btn">Find A Rental</a>
          </li>
          <li className="service-item">
            <div className="service-icon">
              <img src="/assets/images/service-3.png" alt="Sell home" />
            </div>
            <h3 className="h3 service-title">Sell a home</h3>
            <p className="service-text">Over 100+ homes for sale available on the website, we can match you with a house you will want to call home.</p>
            <a href="#" className="btn">Place An Ad</a>
          </li>
        </ul>
      </div>
    </section>
  );
};

export default Services; 