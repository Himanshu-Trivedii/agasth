import './../../styles/CTA.css';

const CTA = () => {
  return (
    <section className="cta" id="contact">
      <div className="container">
        <h2 className="h2 cta-title">Ready to find your dream home?</h2>
        <p className="cta-text">Contact us today and let our experts help you find the perfect property.</p>
        <a href="#" className="btn">Contact Us</a>
      </div>
    </section>
  );
};

export default CTA; 