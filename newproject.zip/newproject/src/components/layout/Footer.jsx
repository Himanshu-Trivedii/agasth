import './../../styles/Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-brand">
          <a href="#" className="logo">
            <img src="/assets/images/logo-light.png" alt="Homeverse logo" />
          </a>
          <p className="footer-text">Your trusted real estate partner. Find your dream home with us.</p>
        </div>
        <ul className="footer-social-list">
          <li><a href="#" className="footer-social-link"><ion-icon name="logo-facebook"></ion-icon></a></li>
          <li><a href="#" className="footer-social-link"><ion-icon name="logo-twitter"></ion-icon></a></li>
          <li><a href="#" className="footer-social-link"><ion-icon name="logo-instagram"></ion-icon></a></li>
        </ul>
        <p className="footer-copyright">&copy; {new Date().getFullYear()} Homeverse. All Rights Reserved.</p>
      </div>
    </footer>
  );
};

export default Footer; 