import { useState, useEffect } from 'react';
import './../../styles/Header.css';

const Header = () => {
  const [isNavbarActive, setIsNavbarActive] = useState(false);
  const [isHeaderActive, setIsHeaderActive] = useState(false);

  const toggleNavbar = () => {
    setIsNavbarActive(!isNavbarActive);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY >= 400) {
        setIsHeaderActive(true);
      } else {
        setIsHeaderActive(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`header ${isHeaderActive ? 'active' : ''}`} data-header>
      <div className={`overlay ${isNavbarActive ? 'active' : ''}`} data-overlay onClick={toggleNavbar}></div>

      <div className="header-top">
        <div className="container">
          <ul className="header-top-list">
            <li>
              <a href="mailto:himanshuoct12@gmail.com" className="header-top-link">
                <ion-icon name="mail-outline"></ion-icon>
                <span>himanshuoct12@gmail.com</span>
              </a>
            </li>
            <li>
              <a href="#" className="header-top-link">
                <ion-icon name="location-outline"></ion-icon>
                <address>NAGPUR</address>
              </a>
            </li>
          </ul>

          <div className="wrapper">
            <ul className="header-top-social-list">
              <li>
                <a href="#" className="header-top-social-link">
                  <ion-icon name="logo-facebook"></ion-icon>
                </a>
              </li>
              <li>
                <a href="#" className="header-top-social-link">
                  <ion-icon name="logo-twitter"></ion-icon>
                </a>
              </li>
              <li>
                <a href="#" className="header-top-social-link">
                  <ion-icon name="logo-instagram"></ion-icon>
                </a>
              </li>
              <li>
                <a href="#" className="header-top-social-link">
                  <ion-icon name="logo-pinterest"></ion-icon>
                </a>
              </li>
            </ul>

            <button className="header-top-btn">Add Listing</button>
          </div>
        </div>
      </div>

      <div className="header-bottom">
        <div className="container">
          <a href="#" className="logo">
            <img src="/assets/images/logo.png" alt="Homeverse logo" />
          </a>

          <nav className={`navbar ${isNavbarActive ? 'active' : ''}`} data-navbar>
            <div className="navbar-top">
              <a href="#" className="logo">
                <img src="/assets/images/logo.png" alt="Homeverse logo" />
              </a>
              <button className="nav-close-btn" data-nav-close-btn onClick={toggleNavbar} aria-label="Close Menu">
                <ion-icon name="close-outline"></ion-icon>
              </button>
            </div>

            <div className="navbar-bottom">
              <ul className="navbar-list">
                <li><a href="#home" className="navbar-link" data-nav-link onClick={toggleNavbar}>Home</a></li>
                <li><a href="#about" className="navbar-link" data-nav-link onClick={toggleNavbar}>About</a></li>
                <li><a href="#service" className="navbar-link" data-nav-link onClick={toggleNavbar}>Service</a></li>
                <li><a href="#property" className="navbar-link" data-nav-link onClick={toggleNavbar}>Property</a></li>
                <li><a href="#blog" className="navbar-link" data-nav-link onClick={toggleNavbar}>Blog</a></li>
                <li><a href="#contact" className="navbar-link" data-nav-link onClick={toggleNavbar}>Contact</a></li>
              </ul>
            </div>
          </nav>

          <div className="header-bottom-actions">
            <button className="header-bottom-actions-btn" aria-label="Search">
              <ion-icon name="search-outline"></ion-icon>
              <span>Search</span>
            </button>
            <button className="header-bottom-actions-btn" aria-label="Profile">
              <ion-icon name="person-outline"></ion-icon>
              <span>Profile</span>
            </button>
            <button className="header-bottom-actions-btn" aria-label="Cart">
              <ion-icon name="cart-outline"></ion-icon>
              <span>Cart</span>
            </button>
            <button className="header-bottom-actions-btn" data-nav-open-btn onClick={toggleNavbar} aria-label="Open Menu">
              <ion-icon name="menu-outline"></ion-icon>
              <span>Menu</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header; 